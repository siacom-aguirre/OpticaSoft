<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
<body>
    <?php 
    include_once 'vaf_nucleo.php';
    nuevoUsuario(); ?>
</body>
</html>