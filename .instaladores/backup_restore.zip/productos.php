<center>
<div class="todo">
  <div id="contenido1">
    <table class='detalleProd'>
    <tbody>
        <?php
        include 'consultas/vaf_catalogo.php';
        ?>
        </tbody>
    </table>
  </div>
</div>
</center>
<?php
include 'footer.php';
?>